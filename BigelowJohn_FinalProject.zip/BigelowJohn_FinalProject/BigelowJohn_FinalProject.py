"""
Program Name: Dice Roller
Version 1.0
Author: John Bigelow
7/25/23
---
::Description::
Program opens a GUI window, which will allow the user to roll 10 dice at the press of a button.
The program will display images and values of different colored dice (Red/Blue) as well as the overall totals.

Default die type is 6-Sided, but 8-Sided and 12-Sided die can be chosen through a drop down menu.

A 'view statistics' button can be pressed to view overall totals of dice rolled since program was started.
(View statistics menu must be closed before continuing on with main program.)

'Exit program' button is also provided, which will terminate Dice Roller.

"""

from tkinter import *
import random
from PIL import ImageTk, Image

#Create Main Window
root= Tk()
root.title('Dice Roller')
root.geometry("550x500")
root.iconbitmap('DiceRollerIcon.ico')

###### VARIABLES ######
#Global Variables --- Used to track statistics
global rolls #of rolls since program started
global dice # of dice rolled since program started
global blue_dice #sum total value of all blue dice rolled since program started
global red_dice #sum total value of all red dice rolled since program started
global all_dice #sum total value of all dice rolled since program started
global sides  #number of sides for currently used dice list

#adding defaults to above global variables
rolls = 0 
dice = 0 
blue_dice = 0 
red_dice = 0 
all_dice = 0 

sides = StringVar() # --- needed for drop_Down widget; keeps track of number of sides on die
sides.set('6 Sides') #default value


###Image Variables --- Defines Image variables for use with PIL module ###
#---Blank Image (default for dice labels)---
img_blank = ImageTk.PhotoImage(Image.open("Blank.png"))

#Image variables: ---6-Sided Blue ---
img_1d6One = ImageTk.PhotoImage(Image.open("1d6One.png"))
img_1d6Two = ImageTk.PhotoImage(Image.open("1d6Two.png"))
img_1d6Three = ImageTk.PhotoImage(Image.open("1d6Three.png"))
img_1d6Four = ImageTk.PhotoImage(Image.open("1d6Four.png"))
img_1d6Five = ImageTk.PhotoImage(Image.open("1d6Five.png"))
img_1d6Six = ImageTk.PhotoImage(Image.open("1d6Six.png"))

#Image variables ---6-Sided Red---
img_1d6OneR = ImageTk.PhotoImage(Image.open("1d6OneR.png"))
img_1d6TwoR = ImageTk.PhotoImage(Image.open("1d6TwoR.png"))
img_1d6ThreeR = ImageTk.PhotoImage(Image.open("1d6ThreeR.png"))
img_1d6FourR = ImageTk.PhotoImage(Image.open("1d6FourR.png"))
img_1d6FiveR = ImageTk.PhotoImage(Image.open("1d6FiveR.png"))
img_1d6SixR = ImageTk.PhotoImage(Image.open("1d6SixR.png"))

#Image variables ---8-Sided Blue---
img_1d8One = ImageTk.PhotoImage(Image.open("1d8One.png"))
img_1d8Two = ImageTk.PhotoImage(Image.open("1d8Two.png"))
img_1d8Three = ImageTk.PhotoImage(Image.open("1d8Three.png"))
img_1d8Four = ImageTk.PhotoImage(Image.open("1d8Four.png"))
img_1d8Five = ImageTk.PhotoImage(Image.open("1d8Five.png"))
img_1d8Six = ImageTk.PhotoImage(Image.open("1d8Six.png"))
img_1d8Seven = ImageTk.PhotoImage(Image.open("1d8Seven.png"))
img_1d8Eight = ImageTk.PhotoImage(Image.open("1d8Eight.png"))

#Image variables ---8-Sided Red---
img_1d8OneR = ImageTk.PhotoImage(Image.open("1d8OneR.png"))
img_1d8TwoR = ImageTk.PhotoImage(Image.open("1d8TwoR.png"))
img_1d8ThreeR = ImageTk.PhotoImage(Image.open("1d8ThreeR.png"))
img_1d8FourR = ImageTk.PhotoImage(Image.open("1d8FourR.png"))
img_1d8FiveR = ImageTk.PhotoImage(Image.open("1d8FiveR.png"))
img_1d8SixR = ImageTk.PhotoImage(Image.open("1d8SixR.png"))
img_1d8SevenR = ImageTk.PhotoImage(Image.open("1d8SevenR.png"))
img_1d8EightR = ImageTk.PhotoImage(Image.open("1d8EightR.png"))

#Image variables ---12-Sided Blue---
img_1d12One = ImageTk.PhotoImage(Image.open("1d12One.png"))
img_1d12Two = ImageTk.PhotoImage(Image.open("1d12Two.png"))
img_1d12Three = ImageTk.PhotoImage(Image.open("1d12Three.png"))
img_1d12Four = ImageTk.PhotoImage(Image.open("1d12Four.png"))
img_1d12Five = ImageTk.PhotoImage(Image.open("1d12Five.png"))
img_1d12Six = ImageTk.PhotoImage(Image.open("1d12Six.png"))
img_1d12Seven = ImageTk.PhotoImage(Image.open("1d12Seven.png"))
img_1d12Eight = ImageTk.PhotoImage(Image.open("1d12Eight.png"))
img_1d12Nine = ImageTk.PhotoImage(Image.open("1d12Nine.png"))
img_1d12Ten = ImageTk.PhotoImage(Image.open("1d12Ten.png"))
img_1d12Eleven = ImageTk.PhotoImage(Image.open("1d12Eleven.png"))
img_1d12Twelve = ImageTk.PhotoImage(Image.open("1d12Twelve.png"))

#Image variables ---12-Sided Red---
img_1d12OneR = ImageTk.PhotoImage(Image.open("1d12OneR.png"))
img_1d12TwoR = ImageTk.PhotoImage(Image.open("1d12TwoR.png"))
img_1d12ThreeR = ImageTk.PhotoImage(Image.open("1d12ThreeR.png"))
img_1d12FourR = ImageTk.PhotoImage(Image.open("1d12FourR.png"))
img_1d12FiveR = ImageTk.PhotoImage(Image.open("1d12FiveR.png"))
img_1d12SixR = ImageTk.PhotoImage(Image.open("1d12SixR.png"))
img_1d12SevenR = ImageTk.PhotoImage(Image.open("1d12SevenR.png"))
img_1d12EightR = ImageTk.PhotoImage(Image.open("1d12EightR.png"))
img_1d12NineR = ImageTk.PhotoImage(Image.open("1d12NineR.png"))
img_1d12TenR = ImageTk.PhotoImage(Image.open("1d12TenR.png"))
img_1d12ElevenR = ImageTk.PhotoImage(Image.open("1d12ElevenR.png"))
img_1d12TwelveR = ImageTk.PhotoImage(Image.open("1d12TwelveR.png"))


######## LISTS ########
# Contains 6 lists for dice image variables (6-sided Red/Blue, 8-Sided Red/Blue, 12-Sided Red/Blue)

#6-Sided Dice List (Blue)
dice_six_list = [img_1d6One, img_1d6Two, img_1d6Three, img_1d6Four, img_1d6Five, img_1d6Six]
#6-Sided Dice List (Red)
dice_six_listR = [img_1d6OneR, img_1d6TwoR, img_1d6ThreeR, img_1d6FourR, img_1d6FiveR, img_1d6SixR]

#8-Sided Dice (Blue)
dice_eight_list = [img_1d8One, img_1d8Two, img_1d8Three, img_1d8Four, img_1d8Five, img_1d8Six, img_1d8Seven, img_1d8Eight ]
#8-Sided Dice (Red)
dice_eight_listR = [img_1d8OneR, img_1d8TwoR, img_1d8ThreeR, img_1d8FourR, img_1d8FiveR, img_1d8SixR, img_1d8SevenR, img_1d8EightR ]

#12-Sided Dice (Blue)
dice_twelve_list = [img_1d12One, img_1d12Two, img_1d12Three, img_1d12Four, img_1d12Five, img_1d12Six, img_1d12Seven, img_1d12Eight, img_1d12Nine, img_1d12Ten, img_1d12Eleven, img_1d12Twelve]
#12-Sided Dice (Red)
dice_twelve_listR = [img_1d12OneR, img_1d12TwoR, img_1d12ThreeR, img_1d12FourR, img_1d12FiveR, img_1d12SixR, img_1d12SevenR, img_1d12EightR,  img_1d12NineR, img_1d12TenR, img_1d12ElevenR, img_1d12TwelveR]


####### FUNCTIONS #######

def open_stats():
    #A function that opens the stat window when called

    #Define Frame
    statsWin = Toplevel() #this is important for grab_set function to work; indicates this is the top window
    statsWin.title('Stats Window')
    statsWin.geometry("250x400")
    statsWin.iconbitmap('DiceRollerIcon.ico')

    #disables all windows below this one
    statsWin.grab_set()
    
    #Label that shows number of rolls since program started
    total_rolls_label = Label(statsWin, text= 'Number of rolls: ' + str(rolls))
    total_rolls_label.grid(row=0, column=0)
    
    #Label that shows the number of dice rolled since program started
    num_dice_label = Label(statsWin, text = "Number of dice rolled: " + str(dice))
    num_dice_label.grid(row=1, column=0)
    
    #Label that shows the total value of all blue dice rolls since program started
    blue_die_total_label = Label(statsWin, text="Total of all blue dice ever rolled: "+ str(blue_dice))
    blue_die_total_label.grid(row=3, column=0)
    
     #Label that shows the total value of all red dice rolls since program started
    red_die_total_label = Label(statsWin, text="Total all red dice ever rolled: "+ str(red_dice))
    red_die_total_label.grid(row=2, column=0)
    
    #Label that shows the total value of all dice rolls since program started
    all_die_total_label = Label(statsWin, text="Total of all dice ever rolled: "+ str(all_dice))
    all_die_total_label.grid(row=4, column=0)

    #Button that closes the stats window
    button_close_stats = Button(statsWin, text='Close Stats', command=statsWin.destroy)
    button_close_stats.grid(row=6, pady=40)



def get_number(x):
    #A function that returns the value of a die based on picture chosen, or (x)

    #Checks which image variable is stored in (x), and returns the cooresponding number value
    if x == img_1d6One or x == img_1d6OneR or x == img_1d8One or x == img_1d8OneR or x == img_1d12One or x == img_1d12OneR:
        return(1)
    elif x == img_1d6Two or x == img_1d6TwoR or x == img_1d8Two or x == img_1d8TwoR or x == img_1d12Two or x == img_1d12TwoR:
        return(2)
    elif x == img_1d6Three or x == img_1d6ThreeR or x == img_1d8Three or x == img_1d8ThreeR or x == img_1d12Three or x == img_1d12ThreeR:
        return(3)
    elif x == img_1d6Four or x == img_1d6FourR or x == img_1d8Four or x == img_1d8FourR or x == img_1d12Four or x == img_1d12FourR:
        return(4)
    elif x == img_1d6Five or x == img_1d6FiveR or x == img_1d8Five or x == img_1d8FiveR or x == img_1d12Five or x == img_1d12FiveR:
        return(5)
    elif x == img_1d6Six or x == img_1d6SixR or x == img_1d8Six or x == img_1d8SixR or x == img_1d12Six or x == img_1d12SixR:
        return(6)
    elif x == img_1d8Seven or x == img_1d8SevenR or x == img_1d12Seven or x == img_1d12SevenR:
        return(7)
    elif x == img_1d8Eight or x == img_1d8EightR or x == img_1d12Eight or x == img_1d12EightR:
        return(8)
    elif x == img_1d12Nine or x == img_1d12NineR:
        return(9)
    elif x == x == img_1d12Ten or x == img_1d12TenR:
        return(10)
    elif x == x == img_1d12Eleven or x == img_1d12ElevenR:
        return(11)
    elif x == x == img_1d12Twelve or x == img_1d12TwelveR:
        return(12)



def roll_dice():
    #Function that runs every time Roll Dice button is clicked
    #Also updates labels on Dice Window
    
    if sides.get() == '6 Sides':
        #If 6 sides is selected, this branch chooses from the list of 6 Sided die faces; 
        # Assigns it to Dice (d#) variables 
        
        #Blue Dice d# variables
        d6 = random.choice(dice_six_list)
        d7 = random.choice(dice_six_list)
        d8 = random.choice(dice_six_list)
        d9 = random.choice(dice_six_list)
        d0 = random.choice(dice_six_list)
        
        #Red Dice d# variables
        d1 = random.choice(dice_six_listR)
        d2 = random.choice(dice_six_listR)
        d3 = random.choice(dice_six_listR)
        d4 = random.choice(dice_six_listR)
        d5 = random.choice(dice_six_listR)

        
    
    elif sides.get() == '8 Sides':   
        #If 8 sides is selected, this branch chooses from the list of 8 Sided die faces; 
        # assigns it to Dice (d#) variables 
        
        #Blue Dice d# variables
        d6 = random.choice(dice_eight_list)
        d7 = random.choice(dice_eight_list)
        d8 = random.choice(dice_eight_list)
        d9 = random.choice(dice_eight_list)
        d0 = random.choice(dice_eight_list)
        
        #Red Dice d# variables
        d1 = random.choice(dice_eight_listR)
        d2 = random.choice(dice_eight_listR)
        d3 = random.choice(dice_eight_listR)
        d4 = random.choice(dice_eight_listR)
        d5 = random.choice(dice_eight_listR)
        
        
        
    elif sides.get() == '12 Sides':
        #If 12 sides is selected, this branch chooses from the list of 8 Sided die faces; 
        # assigns it to Dice (d#) variables 
    
        #Blue Dice d# variables
        d6 = random.choice(dice_twelve_list)
        d7 = random.choice(dice_twelve_list)
        d8 = random.choice(dice_twelve_list)
        d9 = random.choice(dice_twelve_list)
        d0 = random.choice(dice_twelve_list)
    
        #Red Dice d# variables
        d1 = random.choice(dice_twelve_listR)
        d2 = random.choice(dice_twelve_listR)
        d3 = random.choice(dice_twelve_listR)
        d4 = random.choice(dice_twelve_listR)
        d5 = random.choice(dice_twelve_listR)
    
    
    #Assign number values to sublabel variables (sd#) via the get_number function---
    #These sublabel variables (sd#) will be used to display number values below the dice
    
    #Blue Dice sublabel variables set
    sd6 = get_number(d6)
    sd7 = get_number(d7)
    sd8 = get_number(d8)
    sd9 = get_number(d9)
    sd0 = get_number(d0)
    
    #Red Dice sublabel variables set
    sd1 = get_number(d1)
    sd2 = get_number(d2)
    sd3 = get_number(d3)
    sd4 = get_number(d4)
    sd5 = get_number(d5)

    
    
    #Update dice labels & sub-labels ::Blue Dice (Bottom Row)::
    dice_label6.config(image=d6)
    sub_dice_label6.config(text=sd6)
    
    dice_label7.config(image=d7)
    sub_dice_label7.config(text=sd7)
    
    dice_label8.config(image=d8)
    sub_dice_label8.config(text=sd8)
    
    dice_label9.config(image=d9)
    sub_dice_label9.config(text=sd9)
    
    dice_label0.config(image=d0)
    sub_dice_label0.config(text=sd0)
    
    
    #Update dice labels & sub-labels ::Red Dice (Top Row)::
    dice_label1.config(image=d1)
    sub_dice_label1.config(text=sd1)
    
    dice_label2.config(image=d2)
    sub_dice_label2.config(text=sd2)
    
    dice_label3.config(image=d3)
    sub_dice_label3.config(text=sd3)
    
    dice_label4.config(image=d4)
    sub_dice_label4.config(text=sd4)
    
    dice_label5.config(image=d5)
    sub_dice_label5.config(text=sd5)
    
    
    #calculate totals
    total = sd1 + sd2 + sd3 + sd4 + sd5 + sd6 + sd7 + sd8 + sd9 + sd0
    totalA = sd1 + sd2 + sd3 + sd4 + sd5
    totalB = sd6 + sd7 + sd8 + sd9 + sd0
    
    #update totals display on Dice Frame
    total_label_You_Rolled.config(text=f"You rolled: {total}")
    total_label_Red.config(text=f"Red Dice Total: {totalA}")
    total_label_Blue.config(text=f"Blue Dice Total: {totalB}")

    
    #update global variables, for use in stats
    global rolls 
    rolls += 1
    
    global dice
    dice += 10
    
    global red_dice
    red_dice += totalA
    
    global blue_dice
    blue_dice += totalB
    
    global all_dice
    all_dice += totalA + totalB
        

####### WIDGETS #######
#Labels (dice_label#) show die images
#sublabels (sub_dice_label#) show numerical value of die

#Create die window frame
#This extra frame is added to make the display of dice cleaner on the grid
die_frame = Frame(root)
die_frame.grid()

#Labels and sublabels for all dice: Red Group
dice_label1 = Label(die_frame, image = img_blank, font=("Helvetica", 50), fg=("red"))
dice_label1.grid(row=0, column=0)
sub_dice_label1 = Label(die_frame, text="0")
sub_dice_label1.grid(row=1, column=0)

dice_label2 = Label(die_frame, image=img_blank, font=("Helvetica", 50), fg="red")
dice_label2.grid(row=0, column=1)
sub_dice_label2 = Label(die_frame, text="0")
sub_dice_label2.grid(row=1, column=1)

dice_label3 = Label(die_frame, image=img_blank, font=("Helvetica", 50), fg="red")
dice_label3.grid(row=0, column=2)
sub_dice_label3 = Label(die_frame, text="0")
sub_dice_label3.grid(row=1, column=2)

dice_label4 = Label(die_frame, image=img_blank, font=("Helvetica", 50), fg="red")
dice_label4.grid(row=0, column=3)
sub_dice_label4 = Label(die_frame, text="0")
sub_dice_label4.grid(row=1, column=3)

dice_label5 = Label(die_frame, image=img_blank, font=("Helvetica", 50), fg="red")
dice_label5.grid(row=0, column=4)
sub_dice_label5 = Label(die_frame, text="0")
sub_dice_label5.grid(row=1, column=4)


#Labels for all dice: Blue Group
dice_label6 = Label(die_frame, image=img_blank, font=("Helvetica", 50), fg=("blue"))
dice_label6.grid(row=2, column=0)
sub_dice_label6 = Label(die_frame, text="0")
sub_dice_label6.grid(row=3, column=0)

dice_label7 = Label(die_frame, image=img_blank, font=("Helvetica", 50), fg="blue")
dice_label7.grid(row=2, column=1)
sub_dice_label7 = Label(die_frame, text="0")
sub_dice_label7.grid(row=3, column=1)

dice_label8 = Label(die_frame, image=img_blank, font=("Helvetica", 50), fg="blue")
dice_label8.grid(row=2, column=2)
sub_dice_label8 = Label(die_frame, text="0")
sub_dice_label8.grid(row=3, column=2)

dice_label9 = Label(die_frame, image=img_blank, font=("Helvetica", 50), fg="blue")
dice_label9.grid(row=2, column=3)
sub_dice_label9 = Label(die_frame, text="0")
sub_dice_label9.grid(row=3, column=3)

dice_label0 = Label(die_frame, image=img_blank, font=("Helvetica", 50), fg="blue")
dice_label0.grid(row=2, column=4)
sub_dice_label0 = Label(die_frame, text="0")
sub_dice_label0.grid(row=3, column=4)



#label for value of current red dice roll
total_label_Red = Label(die_frame, text="", font=("Helvetica", 8), fg='black')
total_label_Red.grid(row=0,column=5)

#label for value of current blue dice roll
total_label_Blue = Label(die_frame, text="", font=("Helvetica", 8), fg='black')
total_label_Blue.grid(row=2,column=5)

#label for total value of current blue and red roll
total_label_You_Rolled = Label(root, text="", font=("Helvetica", 24), fg='grey')
total_label_You_Rolled.grid(row=3)



#All-Important Roll Dice Button
roll_Button = Button(root, font=('Helvetica', 20), text="Roll Dice", command=roll_dice)
roll_Button.grid()

#Dropdown List
drop_Down = OptionMenu(root, sides, "6 Sides","8 Sides","12 Sides")
drop_Down.grid()

#OpenStats Window
button_stats = Button(root, text='View Stats', command=open_stats)
button_stats.grid()

#Quit Button
button_quit = Button(root, text='Exit Program', command=root.quit)
button_quit.grid(row=5, column= 3)


#roll_dice()
root.mainloop()